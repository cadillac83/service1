package com.ibm.bmw.service;

import com.ibm.bmw.pojo.TestBMWpojo;
import org.springframework.stereotype.Service;

import java.util.List;

/******************************************************************
 *
 *    Java Lib, Powered By Dalian IBM.
 *
 *    Copyright (c) 2001-2018 Dalian IBM Co.,Ltd
 *    http://www.ibm.com/
 *
 *    Package:     com.ibm.bmw.service
 *
 *    Filename:    TestBMWApi
 *
 *    Description: (用一句话描述该文件做什么)
 *
 *    Copyright:   Copyright (c) 2001-2018
 *
 *    Company:     Dalian IBM Co.,Ltd
 *
 *    @author: liuqiang
 *
 *    @version: 1.0.0
 *
 *    Create at:   2019-07-30 10:20
 *
 *    Revision:
 *
 *    2019-07-30 10:20
 *        - first revision
 *
 *****************************************************************/
@Service
public class TestBMWApi {
   public TestBMWpojo TestBMWService() {
       TestBMWpojo testBMWpojo = new TestBMWpojo();
       testBMWpojo.setId("0001");
       testBMWpojo.setName("BMW");
       return testBMWpojo;
   }
}
