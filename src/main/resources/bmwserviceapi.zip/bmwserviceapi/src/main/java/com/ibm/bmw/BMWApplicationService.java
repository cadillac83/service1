package com.ibm.bmw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

/******************************************************************
 *
 *    Java Lib, Powered By Dalian IBM.
 *
 *    Copyright (c) 2001-2018 Dalian IBM Co.,Ltd
 *    http://www.ibm.com/
 *
 *    Package:     PACKAGE_NAME
 *
 *    Filename:    BMWApplicationService
 *
 *    Description: (用一句话描述该文件做什么)
 *
 *    Copyright:   Copyright (c) 2001-2018
 *
 *    Company:     Dalian IBM Co.,Ltd
 *
 *    @author: liuqiang
 *
 *    @version: 1.0.0
 *
 *    Create at:   2019-07-30 16:25
 *
 *    Revision:
 *
 *    2019-07-30 16:25
 *        - first revision
 *
 *****************************************************************/
@SpringBootApplication
@EnableEurekaClient
public class BMWApplicationService {
    public static void main(String[] args) {
        SpringApplication.run(BMWApplicationService.class, args);
    }
}
