package com.ibm.bmw.service.api;

import com.ibm.bmw.pojo.TestBMWpojo;
import com.ibm.bmw.service.TestBMWApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/******************************************************************
 *
 *    Java Lib, Powered By Dalian IBM.
 *
 *    Copyright (c) 2001-2018 Dalian IBM Co.,Ltd
 *    http://www.ibm.com/
 *
 *    Package:     com.ibm.bmw.service.api
 *
 *    Filename:
 *
 *    Description: (用一句话描述该文件做什么)
 *
 *    Copyright:   Copyright (c) 2001-2018
 *
 *    Company:     Dalian IBM Co.,Ltd
 *
 *    @author: liuqiang
 *
 *    @version: 1.0.0
 *
 *    Create at:   2019-07-30 10:45
 *
 *    Revision:
 *
 *    2019-07-30 10:45
 *        - first revision
 *
 *****************************************************************/
@RestController
public class TestBMWController {
    @Autowired
    private TestBMWApi testBMWApi;
    private static Logger logger = LoggerFactory.getLogger(TestBMWController.class);

    @RequestMapping(value = "testBMWapi", produces = {"application/json;charset=UTF-8"}, method = RequestMethod.POST)
    public TestBMWpojo TestBMWController() {
        logger.info("************ Run Service ************");
        return testBMWApi.TestBMWService();
    }
}
